'use strict ';
window.onload = function() {
  
   

}
function switchLight(){
    if( document.body.style.backgroundColor == "red" )
        {
            document.body.style.backgroundColor = "white"; 
            
   
            }
    else{
         document.body.style.backgroundColor = "red"; 
    }
    
}
function changeVehicle()
{
    document.getElementById('ausgabefeld1').value = "Ich reise mit "+document.getElementById('dropdown2').value;
}




function changeLang(){
    var country= document.getElementById('dropdown1').value;
    if(country=='Deutschland')
        { 
            document.getElementById('ausgabefeld1').value="Sprache = Deutsch";
        }
    else if(country=='Italien')
        { 
            document.getElementById('ausgabefeld1').value="Sprache = Italienisch";
        }
    
    else if(country=='Frankreich')
        { 
            document.getElementById('ausgabefeld1').value="Sprache = nicht Englisch";
        }
    else if(country=='Portugal')
        { 
            document.getElementById('ausgabefeld1').value="Sprache = Portugiesisch";
        }
     else if(country=='Spanien')
        { 
            document.getElementById('ausgabefeld1').value="Sprache = Spanisch";
        }
}
